# How To Create Audio Visualizer In Html And Javascript
## Make An Amazing Visualizer With Pure Javascript Audio Api

**Note: This visualizer must run in a host or localhost to work properly**

Watch Tutorial On Youtube 🧡: https://youtu.be/20eapavnQ0U

thumbnail: ![thumbnail](thumbnail.jpg)
